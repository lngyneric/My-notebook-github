import os
import json
import google.generativeai as genai
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any

# ==========================================
# 配置区
# ==========================================
load_dotenv()
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

SKILL_FILE = "academic_tutor_skill.md"
# 优先使用环境变量中的 KB_PATH，如果没有则使用默认的本地路径
KB_PATH = os.getenv("KB_PATH", r"C:\Users\lingyun\Documents\BaiduSyncdisk\xcxnotes\content")

# ==========================================
# 工具函数
# ==========================================

def list_notes():
    """List all markdown files in the knowledge base."""
    files = []
    if not os.path.exists(KB_PATH):
        return ["Error: Knowledge base directory not found."]
        
    for root, _, filenames in os.walk(KB_PATH):
        for filename in filenames:
            if filename.endswith(".md"):
                # Make relative path for cleaner output
                rel_path = os.path.relpath(os.path.join(root, filename), KB_PATH)
                files.append(rel_path)
    return files

def read_note(filename):
    """Read the content of a specific note file."""
    # Security check to prevent reading outside KB_PATH
    full_path = os.path.join(KB_PATH, filename)
    
    # Simple path normalization check
    try:
        full_path = os.path.abspath(full_path)
        base_path = os.path.abspath(KB_PATH)
        if not full_path.startswith(base_path):
             return "Error: Access denied. File is outside knowledge base."
    except Exception:
        return "Error: Invalid path."
    
    if not os.path.exists(full_path):
        return "Error: File not found."
        
    try:
        with open(full_path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        return f"Error reading file: {str(e)}"

def load_system_instruction():
    """读取 SKILL.md 作为 AI 的灵魂"""
    if not os.path.exists(SKILL_FILE):
        return "Error: System instruction file not found."
    with open(SKILL_FILE, "r", encoding="utf-8") as f:
        return f.read()

# ==========================================
# FastAPI 应用
# ==========================================

app = FastAPI(title="Academic Tutor API", description="API for Academic Tutor Chatbot with Local Knowledge Base")

# 配置 CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 模型与会话管理
model = None
sessions: Dict[str, Any] = {}

class ChatRequest(BaseModel):
    message: str
    session_id: str = "default"

class ChatResponse(BaseModel):
    response: str
    session_id: str

@app.on_event("startup")
async def startup_event():
    global model
    system_instruction = load_system_instruction()
    tools = [list_notes, read_note]
    model = genai.GenerativeModel(
        model_name="models/gemini-3-flash-preview",
        system_instruction=system_instruction,
        tools=tools
    )
    print("🎓 Academic Tutor API initialized.")

@app.get("/")
async def root():
    return {"message": "Academic Tutor API is running. Visit /docs for Swagger UI."}

@app.post("/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    global model, sessions
    
    session_id = request.session_id
    user_input = request.message
    
    # 获取或创建会话
    if session_id not in sessions:
        # Enable automatic function calling
        sessions[session_id] = model.start_chat(history=[], enable_automatic_function_calling=True)
        print(f"Created new session: {session_id}")
    
    chat_session = sessions[session_id]
    
    try:
        # stream=False for API simplicity
        response = chat_session.send_message(user_input, stream=False)
        return ChatResponse(response=response.text, session_id=session_id)
    except Exception as e:
        # Handle potential empty response due to function calls only (though auto-calling should handle it)
        # or other errors
        print(f"Error processing request: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/reset/{session_id}")
async def reset_session(session_id: str):
    if session_id in sessions:
        del sessions[session_id]
        return {"message": f"Session {session_id} reset."}
    return {"message": f"Session {session_id} not found."}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
