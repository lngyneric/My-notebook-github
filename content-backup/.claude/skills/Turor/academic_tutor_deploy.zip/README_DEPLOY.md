# Academic Tutor API Deployment Guide

## Files Included
- `tutor_api.py`: The main FastAPI application.
- `requirements.txt`: Python dependencies.
- `start_server.bat`: Windows startup script.
- `Dockerfile`: Docker configuration for containerized deployment.
- `.env.example`: Template for environment variables.
- `academic_tutor_skill.md`: System instruction for the AI model.

## Method 1: Local Deployment (Windows)

1. **Prerequisites**: Ensure Python 3.8+ is installed.
2. **Setup Config**: 
   - Rename `.env.example` to `.env`.
   - Edit `.env` and add your `GEMINI_API_KEY`.
3. **Run**: 
   - Double-click `start_server.bat`.
   - Or run in terminal:
     ```bash
     pip install -r requirements.txt
     python -m uvicorn tutor_api:app --host 0.0.0.0 --port 8000
     ```

## Method 2: Docker Deployment

1. **Build Image**:
   ```bash
   docker build -t academic-tutor-api .
   ```

2. **Run Container**:
   You need to mount your knowledge base directory to `/app/knowledge_base`.
   
   ```bash
   docker run -d -p 8000:8000 \
     --env-file .env \
     -v "C:\path\to\your\notes:/app/knowledge_base" \
     academic-tutor-api
   ```
   
   Replace `C:\path\to\your\notes` with the absolute path to your markdown files.

## API Endpoints

- **Swagger UI**: `http://localhost:8000/docs`
- **Health Check**: `GET /`
- **Chat**: `POST /chat`
  - Body: `{"message": "your question", "session_id": "optional-id"}`

## Notes
- The API allows CORS from `http://localhost:3000`.
- The knowledge base path can be configured via `KB_PATH` environment variable.
